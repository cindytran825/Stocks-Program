How to run from the jar file:
please find the "StocksCindy" folder and put the jar file on the same level as it (so outside the stockscindy folder).
The StocksCindy file should have the src, CSVFiles, and UserPortfolio folders.

How to create portfolio with three different stocks:
You would write 'port-create' into the terminal.
it would then ask for the name of the portfolio of your choosing.
you would then add a ticker and the amount of shares. it would then ask you to
add another ticker, you can add as much as you like.
WHen you are done adding the stocks, hit 'j' and that should add the stocks
into the portfolio.
Creating another portfolio:
You can just do 'port-create' again to make another portfolio (preferably with a different name)
and add as many stocks as you like.
'port-view' to see the list of portfolios you have created.

List of Stocks:
GOOG, AMZN, TSLA, APPL

