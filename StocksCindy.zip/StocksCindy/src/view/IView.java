package view;

public interface IView {
}
