package view;

import javax.swing.*;

public class GUIPortCreate extends JFrame implements GUIView {


}
