package view;

public class GUIPortManage implements GUIView {
}
