package view;

public class GUIPortView implements GUIView {

}
