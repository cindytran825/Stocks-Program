package view;

public interface GUIView {

}
