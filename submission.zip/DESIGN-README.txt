Design -
Our design utilizes the Model, View, Controller design.
We have the Controller interface that has the goControl() method
signature which the StocksController class implements. The controller helps keeps the
view and the model separate.

The Model interface is implemented by the StocksModel class. The methods in this class is
called in the controller. They care called after the user inputs the commands.

The Stocks interface represents all data associated with a stock. It is used to access the
data of the stocks from the data from the API. The Stock class has methods that gets
the data from the stock API and does some of the calculating.

The View interface has the method signatures for the messages that are displayed
for the user. the StockProgramView implements that interface.

The MyDate class is in charge of making sure that the date is valid.

Everytime a user wants a create a portfolio or add to it,
we made a new file to store the data that the user inputs. The Portfolio class
does all the creating and editing the portfolio which is called in the model
when a user needs to access it. If the user wishes to delete anything in it, we just assign the
given stock a new current share value (if we had 50 stocks and wanted to subtract 10, we enter
the same name and label the new share count to 40).

The Dataframe class is used to access the files. It reads the information from the CSV files.
The Alphvantage class was given to us and we used to save the stock files.

We had the portfolio class read from csv files because it doesn't make that much sense to us for
the user having to recreate a new portfolio every time they run the program.

The DataChart class is used to create the bar chart when a user wants a representation of the value
of their portfolio through a timespan. Its in charge of building the charting, scaling it and
formatting  it correctly. It extends the StocksModel class because __________________

==================================================================================
CHANGES:
- change the data type of anything that has to do with shares from int to double. Initially
the directions said that we are not going to allow fractional shares yet, so to ensure that we
worked with integer shares and enforce whole numbers. Now that we can work with fractional shares,
(for balance) we changed all data type integers into data type double
- made changes to the constructor to accommodate for a log. To check value of stocks at given
times, the portfolio will need to implement a log to keep track of transactions, so we had to add
a log to the constructor for initialization as well as a "load" function to read transaction logs
from the file. In doing so, we also changed the format that the file is being read. To accommodate
this new format change, we also had to change the editPortfolio method so that it writes the file
in the proper format. I know this sounds like a lot of change, but it cannot be helped as the format
had to change to accommodate the new directions.
- since the format changed, the getValue method had to change just a little bit with the
introduction of a logging system. It originally used the current (latest) transaction available
with the idea that all the portfolio was being evaluated at a single given date. With the new
addition of a logging system and evaluation of different timestamps, the getValue will now call
getComposition to receive the stock count at a certain time period instead.
- added a method in MyDate to return a string representation of a month integer
- as we did not implement a "buy" or a "sell" method buy combined them in the "editPortfolio",
not that we have been given directions to implement the new methods, we've made the edit portfolio
method private and broke it up into buy and sell. The controller and model had to accommodate this
change. I do think that this change is justified as there were no directions saying that changing
the portfolio had to incorporate a buying and selling method. It is possible to infer that
it could've been refactored into one method based on the given directions in part I.
- Made a new class called DataChart to make the barchart.
- getMonthLength() in the MyDateWithImpl was a private method and I changed that to public because
I needed to call that method in the portfolio class. I thought this decision was reasonable because
I needed to get the length of the month to get the value or each month in the bar chart (needed to
call the method multiple times) and it didn't make sense for me to have duplicate code when I could
just call a method that was already made.
- added getChart() method along with two private helpers in the portfolio class. These methods are
called to get the chart and the new DataChart class has methods that would build the chart.
