package view;

import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

import javax.swing.*;

/**
 * This interface represents the GUI View interface that displays portfolio and its functions
 * (buy/sell and composition/value query).
 */
public interface GUIView extends IView {

  /**
   *  Checks if the window has more than 2 panels on it, and reset the main window if it exceeds
   *  that number.
   */

  void checkComponent();

  /**
   * assigns Java Swing buttons/text/action event to an event listener.
   *
   * @param listener an ActionListener (ideally the controller)
   */
  void setListener(ActionListener listener);

  /**ppp
   *
   */
  void msgBox();

}
